/** Automatically generated file. DO NOT MODIFY */
package com.stackarena.gdaysdemo2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}