package com.stackarena.gdaysdemo2;


import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class DemoActivity extends Activity {
	Button btnGo;
	EditText name_txt;
	final Context context = this;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_demo);

		// lets join our variables to their respective controls
		btnGo = (Button) findViewById(R.id.button1);
		name_txt = (EditText) findViewById(R.id.editText1);

		// this is the button event listener for the click button
		btnGo.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				// check if the person entered a name
				if (name_txt.length() > 1) {

					AlertDialog.Builder builder = new AlertDialog.Builder(context);
					builder.setMessage("Welcome " + name_txt.getText())
							.setTitle("GDays Demo")
							.setPositiveButton("OK", null).show();

				} else {
					Toast.makeText(context,
							"please type in your name", Toast.LENGTH_SHORT)
							.show();
				}
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.demo, menu);
		return true;
	}

}
