
package org.holoeverywhere.addon;

import org.holoeverywhere.app.Application;

public abstract class IAddonApplication extends IAddonBase<Application> {
    public void onCreate() {

    }

    public void onPreCreate() {

    }
}
