/** Automatically generated file. DO NOT MODIFY */
package com.stackarena.gdaysdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}